// flightverse/runtime.js — núcleo del juego: loop de timestep FIJO, input y
// física del dron. Determinismo primero: la simulación avanza en pasos de
// 1/120s con acumulador (el replay y los desafíos dependen de que la física
// NO dependa del framerate); el render interpola entre el estado previo y el
// actual con alpha. Patrón "fix your timestep" clásico.
import * as THREE from '/flightverse/three.js?v=379';
import { CAMERA_RIGS } from '/flightverse/camera-rigs.js?v=379';
import { createStepAccumulator } from '/flightverse/loop-step.js?v=379';
import { MIN_AGL as V2_MIN_AGL } from '/flightverse/physics/index.js?v=379';

export const STEP = 1 / 120;
const MAX_STEPS = 6;             // panic cap: tab de fondo no “explota” al volver

export function createLoop({ update, render, onPause, onResume, timeScale = null }) {
  const accum = createStepAccumulator({ step: STEP, maxSteps: MAX_STEPS, maxDt: 0.25 });
  let last = 0, raf = 0, running = false;
  let frames = 0, fpsT = 0, fps = 0;
  const tick = (tms) => {
    if (!running) return;
    raf = requestAnimationFrame(tick);
    const t = tms / 1000;
    let dt = Math.min(t - (last || t), 0.25);
    last = t;
    const n = accum.feed(dt, timeScale ? timeScale() : 1);   // hit-stop: escala el tiempo, no salta pasos
    for (let i = 0; i < n; i++) update(STEP);
    render(accum.alpha, dt * 1000);
    frames++; fpsT += dt;
    if (fpsT >= 1) { fps = frames / fpsT; frames = 0; fpsT = 0; }
  };
  const onVis = () => { if (document.hidden) pause(); else resume(); };
  function start() { running = true; last = 0; document.addEventListener('visibilitychange', onVis); raf = requestAnimationFrame(tick); }
  function pause() {
    if (!running) return;
    running = false;
    cancelAnimationFrame(raf);
    onPause?.();
  }
  function resume() {
    if (!running) {
      running = true;
      last = 0;
      onResume?.();
      raf = requestAnimationFrame(tick);
    }
  }
  function stop() { pause(); document.removeEventListener('visibilitychange', onVis); }
  return { start, stop, pause, resume, fps: () => fps };
}

// Input: teclado (WASD/QE/RF/Shift/Space) + mouse-look opcional (pointer lock).
// sample() devuelve ejes normalizados [-1..1] — el modo decide qué significan.
export function createInput(el) {
  const keys = new Set();
  let mouseDX = 0, mouseDY = 0, locked = false, enabled = true;
  const typing = t => !!t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName || ''));
  const kd = e => {
    if (!enabled) return;
    // Space = freno: sin esto también re-clickea el último botón enfocado del dock
    if (e.code === 'Space' && !typing(e.target)) e.preventDefault();
    keys.add(e.code);                       // Set dedups; also re-arms a key still held after pause/blur cleared it
  };
  const ku = e => {
    if (enabled && e.code === 'Space' && !typing(e.target)) e.preventDefault();   // el click de <button> sale en keyup (Firefox)
    keys.delete(e.code);
  };
  const mm = e => { if (enabled && locked) { mouseDX += e.movementX; mouseDY += e.movementY; } };
  const lc = () => { locked = document.pointerLockElement === el; };
  let wheelAcc = 0;
  const wh = e => { if (enabled) wheelAcc += e.deltaY; e.preventDefault(); };
  // Cmd-Tab / cambio de pestaña: el keyup nunca llega → soltar teclas para que el dron no siga volando
  const clearKeys = () => { keys.clear(); mouseDX = 0; mouseDY = 0; };
  const onVisClear = () => { if (document.hidden) clearKeys(); };
  addEventListener('keydown', kd); addEventListener('keyup', ku);
  addEventListener('blur', clearKeys); document.addEventListener('visibilitychange', onVisClear);
  addEventListener('mousemove', mm); document.addEventListener('pointerlockchange', lc);
  el.addEventListener('wheel', wh, { passive: false });
  const ax = (neg, pos) => (keys.has(pos) ? 1 : 0) - (keys.has(neg) ? 1 : 0);
  const reset = () => {
    keys.clear();
    mouseDX = 0;
    mouseDY = 0;
    wheelAcc = 0;
    if (locked) document.exitPointerLock?.();
  };
  return {
    keys,
    requestLock: () => { if (enabled) { try { el.requestPointerLock?.()?.catch?.(() => {}); } catch { /* sin gesto / sin foco */ } } },
    releaseLock: () => document.exitPointerLock?.(),
    reset,
    setEnabled(active) {
      enabled = !!active;
      if (!enabled) reset();
    },
    get enabled() { return enabled; },
    get locked() { return locked; },
    sample() {
      if (!enabled) {
        return {
          fwd: 0, strafe: 0, yaw: 0, lift: 0,
          boost: false, brake: false, mouseDX: 0, mouseDY: 0,
        };
      }
      const s = {
        fwd: ax('KeyS', 'KeyW'), strafe: ax('KeyA', 'KeyD'),
        yaw: ax('KeyE', 'KeyQ'), lift: ax('KeyF', 'KeyR'),
        boost: keys.has('ShiftLeft') || keys.has('ShiftRight'),
        brake: keys.has('Space'),
        mouseDX, mouseDY,
      };
      mouseDX = 0; mouseDY = 0;
      return s;
    },
    takeWheel() {
      if (!enabled) return 0;
      const w = wheelAcc; wheelAcc = 0; return w;
    },
    dispose() {
      el.removeEventListener('wheel', wh);
      removeEventListener('keydown', kd); removeEventListener('keyup', ku);
      removeEventListener('blur', clearKeys); document.removeEventListener('visibilitychange', onVisClear);
      removeEventListener('mousemove', mm); document.removeEventListener('pointerlockchange', lc);
    },
  };
}

// Perfiles de vuelo — números tangibles por modo (m/s, rad/s). El modo NO es
// una skin: cambia el modelo de control (velocidad-objetivo vs tasas FPV).
export const MODES = {
  cinematico: { label: 'Cinemático', vmax: 0, tour: true },
  asistido:   { label: 'Normal', vmax: 14, vboost: 24, vy: 9, vyBoost: 16, resp: 3.2, yawRate: 1.6, autoLevel: true, physics: true },
  // Arcade = AUTOPILOTO del vuelo real: recorre el track con estela de luces
  arcade:     { label: 'Arcade', autopilot: true },
  dios:       { label: 'Dios', vmax: 34, vboost: 85, vy: 30, resp: 4.2, yawRate: 1.8, autoLevel: true, noclip: true },
};

// ── 6DOF (port ecctrl): constantes en unidades de nuestro dron (masa 1kg) ──
const G6 = 9.81, MASS6 = 1, DRAG6 = 0.25, TORQUE_RATIO = 0.6;
const TILT_P = 4.2, TILT_D = 1.15, YAW_P = 2.2, HORIZ_P = 1.0, VERT_P = 2.0;
const I6 = 0.06;                               // inercia media (caja 0.85m, 1kg)
const ROTORS6 = [                              // pares diagonales contra-rotantes
  { p: [+0.33, 0, +0.34], s: -1 }, { p: [-0.33, 0, +0.34], s: +1 },
  { p: [+0.33, 0, -0.34], s: +1 }, { p: [-0.33, 0, -0.34], s: -1 },
];
const _up = new THREE.Vector3(0, 1, 0);
const _v1 = new THREE.Vector3(), _v2 = new THREE.Vector3(), _v3 = new THREE.Vector3();
const _v4 = new THREE.Vector3(), _q1 = new THREE.Quaternion();

function step6(d, inp, m, dt) {
  const MT = (m.twr * MASS6 * G6) / 4;         // empuje máx por rotor
  const thr = Math.max(-1, Math.min(1, inp.lift));
  const yaw = Math.max(-1, Math.min(1, inp.yaw - inp.mouseDX * 0.02));
  const pit = Math.max(-1, Math.min(1, inp.fwd));
  const rol = Math.max(-1, Math.min(1, inp.strafe));
  const boost = inp.boost ? 1.4 : 1;

  const by = _v1.set(0, 1, 0).applyQuaternion(d.quat);
  const fwd = _v2.set(0, 0, -1).applyQuaternion(d.quat); fwd.y = 0; fwd.normalize();
  const right = _v3.set(1, 0, 0).applyQuaternion(d.quat); right.y = 0; right.normalize();

  // velocidad objetivo → error → aceleración pedida (clamp a g·tan(tilt))
  const vT = _v4.copy(right).multiplyScalar(rol * m.vmaxH * boost)
    .addScaledVector(fwd, pit * m.vmaxH * boost)
    .addScaledVector(_up, thr * m.vmaxV * boost);
  vT.sub(d.vel);                               // vErr
  const aV = Math.max(-G6, Math.min(G6, vT.y * VERT_P));
  const aH = vT.clone(); aH.y = 0; aH.multiplyScalar(HORIZ_P);
  const aHmax = G6 * Math.tan(m.tilt);
  if (aH.length() > aHmax) aH.setLength(aHmax);

  // hover feed-forward (auto-compensa el tilt) + PD de actitud
  const hover = Math.max(0, Math.min(1, (MASS6 * (G6 + aV)) / (4 * MT * Math.max(0.25, by.y))));
  const targetUp = aH.clone().addScaledVector(_up, G6).normalize();
  const tiltErr = new THREE.Vector3().crossVectors(by, targetUp);
  const tau = tiltErr.multiplyScalar(TILT_P)
    .addScaledVector(new THREE.Vector3(d.angVel.x, 0, d.angVel.z), -TILT_D)
    .addScaledVector(_up, (yaw * m.yawRate - d.angVel.y) * YAW_P);
  const tauBody = tau.applyQuaternion(_q1.copy(d.quat).invert());

  // mixer normalizado + fuerzas (empuje = +Y local de cada rotor)
  const maxMix = Math.min(1 - hover, hover) || 0.01;
  const F = new THREE.Vector3(0, -G6 * MASS6, 0).addScaledVector(d.vel, -DRAG6);
  const T = new THREE.Vector3();
  for (const r of ROTORS6) {
    const mix = tauBody.z * (r.p[0] > 0 ? -1 : 1) * 0.25
              + tauBody.x * (r.p[2] > 0 ? 1 : -1) * 0.25
              + tauBody.y * r.s * 0.25 / TORQUE_RATIO * 0.6;
    const t = Math.max(0, Math.min(1, hover + Math.max(-maxMix, Math.min(maxMix, mix))));
    const thrust = _v1.set(0, MT * t, 0).applyQuaternion(d.quat);
    F.add(thrust);
    const rw = _v2.set(...r.p).applyQuaternion(d.quat);
    T.add(_v3.crossVectors(rw, thrust));
    T.addScaledVector(by, r.s * TORQUE_RATIO * MT * t * 0.1);
  }
  if (inp.brake) d.vel.multiplyScalar(Math.exp(-dt * 4));
  d.vel.addScaledVector(F, dt / MASS6);
  d.pos.addScaledVector(d.vel, dt);
  d.angVel.addScaledVector(T, dt / I6);
  d.angVel.multiplyScalar(Math.exp(-dt * 2.4));           // damping aerodinámico
  if (d.angVel.length() > 5) d.angVel.setLength(5);       // sin barrenas imposibles
  // integrar quaternion: dq = 0.5·ω·q·dt
  const w = d.angVel;
  _q1.set(w.x * dt / 2, w.y * dt / 2, w.z * dt / 2, 0).multiply(d.quat);
  d.quat.x += _q1.x; d.quat.y += _q1.y; d.quat.z += _q1.z; d.quat.w += _q1.w;
  d.quat.normalize();
  // derivar yaw/pitch para rigs y HUD
  const f2 = _v1.set(0, 0, -1).applyQuaternion(d.quat);
  d.yaw = Math.atan2(-f2.x, -f2.z);
  d.pitch = Math.asin(Math.max(-1, Math.min(1, f2.y)));
}

const MIN_AGL = V2_MIN_AGL;     // 1.2 m: el dron nunca “entra” al terreno: piso duro honesto (igual en v1 y v2)
const DEFAULT_DRONE_COLLISION_RADIUS = 0.59;
const MIN_DRONE_COLLISION_RADIUS = 0.42;
const MAX_DRONE_COLLISION_RADIUS = 0.70;
const _n = new THREE.Vector3();  // scratch de la respuesta de colisión
const _start = new THREE.Vector3(), _desired = new THREE.Vector3();
const _current = new THREE.Vector3(), _remaining = new THREE.Vector3();
const _next = new THREE.Vector3();
const _cameraBoom = new THREE.Vector3();

export function resolveCameraCollision(world, focus, desired, clearance = 0.18) {
  if (!world?.castSegment || !focus?.isVector3 || !desired?.isVector3) return null;
  const boomLength = _cameraBoom.subVectors(desired, focus).length();
  if (!Number.isFinite(boomLength) || boomLength <= 1e-7) return null;
  try {
    const hit = world.castSegment(focus, desired, 0);
    if (!hit || !Number.isFinite(hit.fraction)) return null;
    const margin = Number.isFinite(clearance) ? Math.max(0, clearance) : 0.18;
    const safeDistance = Math.max(
      0.05,
      THREE.MathUtils.clamp(hit.fraction, 0, 1) * boomLength - margin,
    );
    desired.copy(focus).addScaledVector(_cameraBoom, safeDistance / boomLength);
    return hit;
  } catch {
    return null;
  }
}

export function createDrone({ world, spawn }) {
  const d = {
    pos: new THREE.Vector3(...(spawn?.position_m || [0, 60, 0])),
    vel: new THREE.Vector3(),
    quat: new THREE.Quaternion(), angVel: new THREE.Vector3(),
    yaw: 0, pitch: 0,
    prev: { pos: new THREE.Vector3(), yaw: 0, pitch: 0, quat: new THREE.Quaternion() },
    v2: null,                       // Physics v2 (?fv=2 / ?phys=v2): ver attachV2()
    agl: null, crashedSoft: false, distance: 0,
    collisionHits: 0, collisionFailures: 0, _t: 0,
    collisionRadius: DEFAULT_DRONE_COLLISION_RADIUS,
  };
  d.prev.pos.copy(d.pos);
  const collisionRadii = {
    structure: d.collisionRadius,
    terrain: MIN_AGL,
    boundary: d.collisionRadius,
  };
  d.setCollisionRadius = (value) => {
    const radius = Number(value);
    if (!Number.isFinite(radius)) return d.collisionRadius;
    d.collisionRadius = THREE.MathUtils.clamp(
      radius,
      MIN_DRONE_COLLISION_RADIUS,
      MAX_DRONE_COLLISION_RADIUS,
    );
    collisionRadii.structure = d.collisionRadius;
    collisionRadii.boundary = d.collisionRadius;
    if (d.v2) {
      d.v2.sim.radii.structure = d.collisionRadius;
      d.v2.sim.radii.boundary = d.collisionRadius;
    }
    return d.collisionRadius;
  };

  // ── Physics v2 (WS C, detrás de ?fv=2 / ?phys=v2) ──
  // El sim (physics/sim.js) es puro y vive fuera de three; aquí solo se adapta:
  // comandos del piloto -> sim, estado del sim -> d.pos/vel/quat/yaw (los demás
  // módulos siguen leyendo el mismo objeto dron) y render interpolado con actitud.
  const _qa = new THREE.Quaternion(), _fa = new THREE.Vector3(), _ra = new THREE.Vector3(), _ua = new THREE.Vector3();
  d.attachV2 = (sim) => {
    d.v2 = {
      sim, seeded: false, active: false,
      lastPos: new THREE.Vector3(), lastYaw: 0, steps: 0,
    };
    sim.radii.structure = d.collisionRadius;
    sim.radii.boundary = d.collisionRadius;
    return d.v2;
  };
  d.detachV2 = () => { d.v2 = null; };

  function seedV2(v2) {
    const sim = v2.sim;
    sim.reseed(d.pos.x, d.pos.y, d.pos.z, d.yaw, d.vel.x, d.vel.y, d.vel.z);
    d.quat.set(sim.s.q[1], sim.s.q[2], sim.s.q[3], sim.s.q[0]);
    d.prev.quat.copy(d.quat);
    v2.seeded = true;
  }

  function stepV2(dt, inp) {
    const v2 = d.v2, sim = v2.sim, s = sim.s;
    if (!v2.seeded || d.pos.distanceToSquared(v2.lastPos) > 1e-6 || Math.abs(d.yaw - v2.lastYaw) > 1e-5) {
      seedV2(v2);                              // teletransporte externo (Gate Rush, autopiloto, replay…)
    }
    v2.active = true;
    // mirada: radianes ya procesados por input/v2-input.js; sin eso (?phys=v2 solo), mouse legacy en px
    let lookYaw = inp.lookYaw, lookPitch = inp.lookPitch;
    if (lookYaw === undefined) { lookYaw = -(inp.mouseDX || 0) * 0.0022; lookPitch = -(inp.mouseDY || 0) * 0.0018; }
    d.pitch = THREE.MathUtils.clamp(d.pitch + (lookPitch || 0), -1.2, 1.2);   // pitch de mirada: se mantiene
    if (lookYaw) sim.addYaw(lookYaw);
    const before = _start;
    sim.step(dt, inp);
    d.pos.set(s.p[0], s.p[1], s.p[2]);
    d.vel.set(s.v[0], s.v[1], s.v[2]);
    d.angVel.set(s.w[0], s.w[1], s.w[2]);
    d.quat.set(s.q[1], s.q[2], s.q[3], s.q[0]);
    d.yaw = sim.att.yaw;
    const ground = world?.groundHeight?.(d.pos.x, d.pos.z);
    d.agl = ground == null ? null : d.pos.y - ground;
    d.crashedSoft = false;                     // v2 reporta impactos por hooks (bus crash)
    d.collisionHits = sim.stats.contacts;
    d.collisionFailures = sim.stats.collisionFailures;
    d.distance += before.distanceTo(d.pos);
    v2.lastPos.copy(d.pos); v2.lastYaw = d.yaw;
    v2.steps += 1;
  }

  d.step = (dt, inp, modeKey) => {
    const m = MODES[modeKey] || MODES.asistido;
    d.prev.pos.copy(d.pos); d.prev.yaw = d.yaw; d.prev.pitch = d.pitch; d.prev.quat.copy(d.quat);
    _start.copy(d.pos);
    if (m.tour) return;                       // cinemático: la cámara vuela, no el dron
    if (d.v2 && m.physics) { stepV2(dt, inp); return; }
    if (d.v2) { d.v2.seeded = false; d.v2.active = false; }   // Dios/Arcade: integrador viejo; al volver se re-siembra

    if (m.six) {                               // FPV/Arcade: rígido 6DOF real
      step6(d, inp, m, dt);
      applyWorldConstraints(d, m, _start);
      d.distance += _start.distanceTo(d.pos);
      return;
    }
    // sincronizar quat con el heading del modo asistido (cambio de modo suave)
    d.quat.setFromAxisAngle(_up, d.yaw); d.angVel.set(0, 0, 0);

    d.yaw += inp.yaw * m.yawRate * dt - inp.mouseDX * 0.0022;   // teclas=tasa, mouse=directo
    d.pitch = THREE.MathUtils.clamp(d.pitch - inp.mouseDY * 0.0018, -1.2, 1.2);
    if (m.autoLevel) d.pitch *= Math.exp(-dt * 2.5);

    const vmax = inp.boost ? m.vboost : m.vmax;
    const sin = Math.sin(d.yaw), cos = Math.cos(d.yaw);
    // objetivo de velocidad en el frame del mundo a partir del heading
    const tx = (inp.fwd * -sin + inp.strafe * cos) * vmax;
    const tz = (inp.fwd * -cos - inp.strafe * sin) * vmax;
    const vyMax = inp.boost ? (m.vyBoost || m.vy * 1.8) : m.vy;   // el turbo TAMBIÉN sube
    const ty = inp.lift * vyMax;
    const k = 1 - Math.exp(-dt * m.resp);
    d.vel.x += (tx - d.vel.x) * k;
    d.vel.z += (tz - d.vel.z) * k;
    d.vel.y += (ty - d.vel.y) * (1 - Math.exp(-dt * (m.resp + 1.5)));
    if (inp.brake) d.vel.multiplyScalar(Math.exp(-dt * 6));

    // viento determinista (replay-safe): rachas suaves de ~1.2 m/s que
    // derivan el hover como un Flip real; el drag del modo lo compensa
    d._t += dt;
    // GPS-hold honesto: un dron real con sticks sueltos SE QUEDA (position
    // hold); el viento solo se siente en movimiento. Sin esto, en iPad el
    // hover derivaba a la izquierda sin tocar nada.
    const flying = Math.abs(inp.fwd) + Math.abs(inp.strafe) + Math.abs(inp.lift) > 0.05
      || d.vel.length() > 2;
    if (flying) {
      const wx = Math.sin(d._t * 0.13 + 1.7) + Math.sin(d._t * 0.041) * 0.6;
      const wz = Math.cos(d._t * 0.09) + Math.sin(d._t * 0.023 + 0.8) * 0.5;
      d.vel.x += wx * 0.5 * dt; d.vel.z += wz * 0.5 * dt;
    }

    d.pos.addScaledVector(d.vel, dt);
    applyWorldConstraints(d, m, _start);
    d.distance += _start.distanceTo(d.pos);
  };

  function applyWorldConstraints(d, m, safeStart) {
    const ground = world?.groundHeight?.(d.pos.x, d.pos.z);
    d.agl = ground == null ? null : d.pos.y - ground;
    d.crashedSoft = false;
    if (m.noclip) {
      const back = world?.boundaryClamp?.(d.pos, d.collisionRadius);
      if (back) {
        d.pos.add(back);
        d.vel.x = 0; d.vel.z = 0;               // no acumular velocidad contra el borde
      }
      return;
    }
    if (!world?.sweepSphere) return;

    try {
      _desired.copy(d.pos);
      _current.copy(safeStart);

      // Deterministic spawn/stale-pose recovery. Terrain hits carry the exact
      // legal center; mesh hits carry closest distance + outward normal.
      const recovery = world.recoverSphere?.(_current, collisionRadii);
      if (recovery?.translation) {
        _current.add(recovery.translation);
        _n.copy(recovery.normal).normalize();
        d.collisionHits += 1;
      }
      const embedded = recovery
        ? null
        : world.sweepSphere(_current, _current, collisionRadii);
      if (embedded?.fraction === 0) {
        _n.copy(embedded.normal).normalize();
        if (embedded.kind === 'terrain' || embedded.kind === 'boundary') {
          _current.copy(embedded.point).addScaledVector(_n, 0.003);
        } else {
          const penetration = Math.max(
            0.003,
            d.collisionRadius - (Number(embedded.distance) || 0) + 0.003,
          );
          _current.addScaledVector(_n, penetration);
        }
        d.collisionHits += 1;
      }

      _remaining.subVectors(_desired, safeStart);
      for (let contact = 0; contact < 2; contact += 1) {
        if (_remaining.lengthSq() <= 1e-10) break;
        _next.copy(_current).add(_remaining);
        const hit = world.sweepSphere(_current, _next, collisionRadii);
        if (!hit) {
          _current.copy(_next);
          _remaining.set(0, 0, 0);
          break;
        }
        _n.copy(hit.normal).normalize();
        const travel = Math.max(0, hit.fraction - 1e-4);
        _current.addScaledVector(_remaining, travel).addScaledVector(_n, 0.003);
        _remaining.multiplyScalar(Math.max(0, 1 - hit.fraction));
        const remainingNormal = _remaining.dot(_n);
        if (remainingNormal < 0) {
          _remaining.addScaledVector(_n, -remainingNormal);
        }
        const velocityNormal = d.vel.dot(_n);
        if (velocityNormal < 0) d.vel.addScaledVector(_n, -velocityNormal);
        d.crashedSoft ||= velocityNormal < -6;
        d.collisionHits += 1;
      }

      if (_remaining.lengthSq() > 1e-10) {
        _next.copy(_current).add(_remaining);
        if (!world.sweepSphere(_current, _next, collisionRadii)) {
          _current.copy(_next);
        }
      }
      if (
        Number.isFinite(_current.x)
        && Number.isFinite(_current.y)
        && Number.isFinite(_current.z)
      ) {
        d.pos.copy(_current);
      } else {
        d.pos.copy(safeStart);
        d.vel.set(0, 0, 0);
        d.collisionFailures += 1;
      }
    } catch {
      d.pos.copy(safeStart);
      d.vel.set(0, 0, 0);
      d.collisionFailures += 1;
    }
    const resolvedGround = world.groundHeight?.(d.pos.x, d.pos.z);
    d.agl = resolvedGround == null ? null : d.pos.y - resolvedGround;
    if (d.agl != null && d.agl < MIN_AGL - 0.01) {
      d.pos.copy(safeStart);
      d.vel.set(0, 0, 0);
      d.collisionFailures += 1;
    }
  }

  d.lerpPose = (alpha, outPos) => {
    outPos.lerpVectors(d.prev.pos, d.pos, alpha);
    if (d.v2?.active) {
      // v2: actitud real del cuerpo (slerp) -> el dron se inclina y cabecea de verdad
      const q = _qa.slerpQuaternions(d.prev.quat, d.quat, alpha);
      _fa.set(0, 0, -1).applyQuaternion(q);
      _ra.set(1, 0, 0).applyQuaternion(q);
      _ua.set(0, 1, 0).applyQuaternion(q);
      return {
        yaw: Math.atan2(-_fa.x, -_fa.z),
        pitch: THREE.MathUtils.lerp(d.prev.pitch, d.pitch, alpha),       // pitch de mirada (apuntado)
        bodyPitch: Math.asin(THREE.MathUtils.clamp(_fa.y, -1, 1)),
        roll: Math.atan2(-_ra.y, _ua.y),
        quat: q.clone(),
        v2: true,
      };
    }
    return { yaw: THREE.MathUtils.lerp(d.prev.yaw, d.yaw, alpha),
             pitch: THREE.MathUtils.lerp(d.prev.pitch, d.pitch, alpha) };
  };
  return d;
}

// Immutable camera metadata. Per-session phase, gimbal ownership and pose math
// live in camera-rigs.js; exported here only for existing menu labels/contracts.
export const RIGS = CAMERA_RIGS;
