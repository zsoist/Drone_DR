// flightverse/gaterush.js — Gate Rush v2: dificultades (fácil/media/difícil),
// aros HD con spin/beacon/flash de paso, migas de luz fluyendo por la ruta,
// splits por gate. Circuito HONESTO: gates sobre la ruta del vuelo REAL
// (track GPS en frame local); sin track: anillo procedural documentado como
// fallback. Detección por proximidad en timestep fijo (determinista → replay).
import * as THREE from '/flightverse/three.js?v=370';
import { createSpeedTracker, topSpeedFor } from '/flightverse/gate-stats.js?v=370';
import { segmentPassesGate } from '/flightverse/collision-math.js?v=370';
import {
  courseLength, parTime, gateRushMedal, gateRushScore, paceDelta, timeText, findClearStart,
  ghostPoseAt, START_CLEARANCE_M, sanitizeGateCenters,
} from '/flightverse/modes/rules.js?v=370';

export const DIFFS = {
  facil:   { label: 'Fácil',   n: 8,  r: 9,   pass: 1.25, color: 0x52C79A },
  media:   { label: 'Media',   n: 10, r: 6.5, pass: 1.12, color: 0x45A0E6 },
  dificil: { label: 'Difícil', n: 13, r: 4.2, pass: 1.05, color: 0x9a6cff },
};

function glowSprite(color) {
  const cv = document.createElement('canvas'); cv.width = cv.height = 48;
  const c = cv.getContext('2d');
  const g = c.createRadialGradient(24, 24, 1, 24, 24, 23);
  g.addColorStop(0, 'rgba(255,255,255,.95)'); g.addColorStop(0.4, 'rgba(160,200,255,.5)');
  g.addColorStop(1, 'rgba(120,170,255,0)');
  c.fillStyle = g; c.fillRect(0, 0, 48, 48);
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({
    map: new THREE.CanvasTexture(cv), transparent: true, depthWrite: false,
    blending: THREE.AdditiveBlending, color }));
  return sp;
}

function disposeMaterial(m) {
  if (!m) return;
  if (m.map) m.map.dispose();
  m.dispose();
}
function disposeObject(o) {
  if (!o.isSprite) o.geometry?.dispose();   // la geometría del Sprite es compartida por three
  if (Array.isArray(o.material)) o.material.forEach(disposeMaterial);
  else disposeMaterial(o.material);
}

export function createGateRush({ scene, trackPts, world, heightAt, difficulty = 'media', v2 = false, collision = null, worldPar = null, ghost = null }) {
  const D = DIFFS[difficulty] || DIFFS.media;
  const GATE_R = D.r, PASS_R = GATE_R * D.pass;

  // ── curso ──
  let centers = [];
  if (trackPts?.length > 20) {
    const stepN = Math.max(1, Math.floor(trackPts.length / (D.n + 1)));
    for (let i = stepN; i < trackPts.length && centers.length < D.n; i += stepN) {
      centers.push(trackPts[i].clone());
    }
  } else {
    const R = Math.min(...world.size_m) * 0.32;
    for (let i = 0; i < D.n; i++) {
      const a = (i / D.n) * Math.PI * 2;
      const x = Math.cos(a) * R, z = Math.sin(a) * R;
      const g = heightAt(x, z);
      // difícil: altura variada = curvas de verdad
      const dy = difficulty === 'dificil' ? Math.sin(i * 2.1) * 14 : 0;
      centers.push(new THREE.Vector3(x, (g ?? 0) + 22 + dy, z));
    }
  }
  let sanitation = null;
  if (v2 && collision?.boundaryClamp) {            // gates alcanzables: dentro del borde jugable y fuera de la malla
    const res = sanitizeGateCenters(centers, {
      radius: GATE_R,
      nearest: p => {
        const h = collision.closest?.(p, GATE_R);
        return h && h.kind === 'structure' ? h.distance : Infinity;
      },
      clampFn: (p, r) => collision.boundaryClamp(p, r),
    });
    sanitation = res.report;
    if (res.centers.length >= 4) centers = res.centers.map(c => new THREE.Vector3(c.x, c.y, c.z));
  }
  centers = centers.map(c => {                    // jamás bajo el terreno
    const g = heightAt(c.x, c.z);
    if (g != null && c.y < g + GATE_R + 2) c.y = g + GATE_R + 2;
    return c;
  });

  const grp = new THREE.Group();
  const cNext = new THREE.Color(D.color);
  const matNext = new THREE.MeshLambertMaterial({ color: D.color, emissive: cNext.clone().multiplyScalar(0.35) });
  const matIdle = new THREE.MeshLambertMaterial({ color: 0x566274 });
  const matDone = new THREE.MeshLambertMaterial({ color: 0x52C79A, transparent: true, opacity: 0.3 });
  // aros HD: torus denso + aro fino interior + glow + beam al suelo
  const ringGeo = new THREE.TorusGeometry(GATE_R, GATE_R * 0.06, 24, 96);
  const trimGeo = new THREE.TorusGeometry(GATE_R * 0.88, GATE_R * 0.018, 12, 72);
  const gates = centers.map((c, i) => {
    const next = centers[i + 1] || centers[i - 1] || c.clone().add(new THREE.Vector3(1, 0, 0));
    const m = new THREE.Mesh(ringGeo, matIdle);
    m.position.copy(c);
    m.lookAt(next);
    const trim = new THREE.Mesh(trimGeo, new THREE.MeshBasicMaterial({
      color: 0xffffff, transparent: true, opacity: 0.25,
      blending: THREE.AdditiveBlending, depthWrite: false }));
    m.add(trim);
    const glow = new THREE.Mesh(
      new THREE.TorusGeometry(GATE_R * 1.12, GATE_R * 0.11, 12, 72),
      new THREE.MeshBasicMaterial({ color: D.color, transparent: true, opacity: 0.12,
        blending: THREE.AdditiveBlending, depthWrite: false }));
    m.add(glow);
    // beacon: columna de luz al suelo bajo el gate activo
    const gy = heightAt(c.x, c.z) ?? (c.y - 25);
    const beamH = Math.max(4, c.y - gy);
    const beam = new THREE.Mesh(
      new THREE.CylinderGeometry(0.5, 1.4, beamH, 10, 1, true),
      new THREE.MeshBasicMaterial({ color: D.color, transparent: true, opacity: 0,
        blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide }));
    beam.position.set(c.x, gy + beamH / 2, c.z);
    grp.add(beam);
    grp.add(m);
    return { mesh: m, trim, glow, beam, center: c, passed: false };
  });

  // camino con gradiente + MIGAS de luz que fluyen hacia el siguiente gate
  const curve = new THREE.CatmullRomCurve3(centers, false, 'catmullrom', 0.35);
  const pathGeo = new THREE.TubeGeometry(curve, centers.length * 14, 0.45, 8, false);
  const nP = pathGeo.attributes.position.count;
  const colors = new Float32Array(nP * 3);
  const cA = new THREE.Color(D.color), cB = new THREE.Color(0x9a6cff);
  for (let i = 0; i < nP; i++) {
    const c2 = cA.clone().lerp(cB, 0.5 + 0.5 * Math.sin((i / nP) * Math.PI * 6));
    colors[i * 3] = c2.r; colors[i * 3 + 1] = c2.g; colors[i * 3 + 2] = c2.b;
  }
  pathGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  const pathMat = new THREE.MeshBasicMaterial({ vertexColors: true, transparent: true,
    opacity: 0.3, blending: THREE.AdditiveBlending, depthWrite: false });
  grp.add(new THREE.Mesh(pathGeo, pathMat));
  const crumbs = [];
  for (let i = 0; i < 14; i++) {
    const sp = glowSprite(D.color);
    sp.scale.setScalar(1.6);
    grp.add(sp);
    crumbs.push(sp);
  }
  scene.add(grp);

  const st = {
    phase: 'idle',                 // idle | countdown | running | finished
    idx: 0, total: gates.length, difficulty,
    t: 0, countdown: 0, time: null, topSpeed: 0, avgSpeed: 0,
    splits: [], lastSplit: null,   // tiempos por gate (el HUD muestra el delta)
    rec: [],
    // v2: par, fallos, medalla, inicio validado
    par: null, misses: 0, medal: null, score: 0, startInfo: null, sanitation,
  };
  // ── v2: fantasma translúcido de la mejor run ──
  let ghostMesh = null;
  const ghostState = { data: ghost, enabled: !!ghost };
  function buildGhostMesh() {
    const g = new THREE.Group();
    const mat = new THREE.MeshBasicMaterial({ color: 0x45A0E6, transparent: true, opacity: 0.38, depthWrite: false });
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.14, 0.7), mat);
    const armA = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.06, 0.12), mat); armA.rotation.y = Math.PI / 4;
    const armB = armA.clone(); armB.rotation.y = -Math.PI / 4;
    g.add(body, armA, armB);
    g.visible = false;
    grp.add(g);
    return g;
  }
  if (v2) ghostMesh = buildGhostMesh();
  let recSkip = 0;
  const prevPos = new THREE.Vector3();
  let havePrev = false;
  const speedTracker = createSpeedTracker();
  const gateNormal = new THREE.Vector3();
  const flashes = [];              // anillos de celebración al pasar un gate
  const _d = new THREE.Vector3(), _d2 = new THREE.Vector3();

  function paint() {
    gates.forEach((g, i) => {
      g.mesh.material = g.passed ? matDone : (i === st.idx ? matNext : matIdle);
    });
  }
  paint();

  return {
    state: st,
    gates,
    setVisible(v) { grp.visible = v; },       // replay/director: vuelo puro, sin velos

    // punto de aproximación: 16m antes del gate 0, en su eje de entrada
    approach() {
      const c0 = centers[0], c1 = centers[1] || c0.clone().add(new THREE.Vector3(1, 0, 0));
      const dir = c0.clone().sub(c1).normalize();
      const nominal = c0.clone().addScaledVector(dir, 16);
      if (!v2 || !collision) return nominal;
      // v2: ≥ 12 m de cualquier muro y 30 m libres al frente; si no, se desliza por el eje de entrada
      const axis = { x: -dir.x, y: -dir.y, z: -dir.z };     // dirección de vuelo hacia el gate 0
      const structural = p => {
        const hit = collision.closest?.(p, START_CLEARANCE_M);
        if (!hit) return true;
        if (hit.kind === 'terrain') return hit.distance > 3;      // el suelo solo importa muy cerca
        return false;
      };
      const res = findClearStart({
        approach: nominal, axis,
        clearAt: structural,
        rayClear: (p, a) => !collision.castSegment(p, { x: p.x + a.x * 30, y: p.y + a.y * 30, z: p.z + a.z * 30 }, 0.6),
      });
      st.startInfo = { ok: res.ok, moved: res.moved, attempts: res.attempts, nominalMoved: nominal.distanceTo(new THREE.Vector3(res.point.x, res.point.y, res.point.z)) };
      return new THREE.Vector3(res.point.x, res.point.y, res.point.z);
    },
    /** Datos que dibuja el HUD (A): cronómetro, contador de gates, par, ritmo. Siempre disponible. */
    hud() {
      return {
        phase: st.phase, t: st.phase === 'running' ? st.t : (st.time ?? 0),
        timerText: timeText(st.phase === 'running' ? st.t : (st.time ?? 0)),
        gate: Math.min(st.idx + (st.phase === 'finished' ? 0 : 1), st.total), passed: st.idx, total: st.total,
        par: st.par, misses: st.misses,
        pace: st.par ? paceDelta({ t: st.t, idx: st.idx, total: st.total, par: st.par }) : 0,
        countdown: st.phase === 'countdown' ? Math.max(1, Math.ceil(st.countdown)) : 0,
        difficulty, medal: st.medal,
      };
    },
    noteMiss() { if (st.phase === 'running') st.misses++; },
    setGhost(data) { ghostState.data = data; if (ghostMesh) ghostMesh.visible = false; },
    setGhostEnabled(v) { ghostState.enabled = !!v; if (!v && ghostMesh) ghostMesh.visible = false; },
    get ghostActive() { return !!(ghostMesh && ghostState.enabled && ghostState.data); },
    pulse(t, dt = 0.016) {
      pathMat.opacity = 0.24 + Math.sin(t * 2.6) * 0.08;
      gates.forEach((gg, i) => {
        const active = i === st.idx && st.phase !== 'finished';
        gg.glow.material.opacity = active ? 0.2 + Math.sin(t * 4) * 0.12 : 0.05;
        gg.trim.material.opacity = active ? 0.4 + Math.sin(t * 6) * 0.2 : 0.1;
        gg.beam.material.opacity = active ? 0.09 + Math.sin(t * 3) * 0.05 : 0;
        if (active) {
          gg.mesh.rotation.z += dt * 0.5;              // spin ceremonial
          const s = 1 + Math.sin(t * 3.2) * 0.025;
          gg.mesh.scale.setScalar(s);
        } else gg.mesh.scale.setScalar(1);
      });
      crumbs.forEach((sp, i) => {                      // migas fluyendo
        const u = (t * 0.022 + i / crumbs.length) % 1;
        sp.position.copy(curve.getPointAt(u));
        sp.material.opacity = 0.35 + Math.sin(t * 5 + i) * 0.25;
      });
      for (let i = flashes.length - 1; i >= 0; i--) {  // celebración de paso
        const f = flashes[i];
        f.k += dt * 2.2;
        if (f.k >= 1) { grp.remove(f.m); disposeObject(f.m); flashes.splice(i, 1); continue; }
        f.m.scale.setScalar(1 + f.k * 1.1);
        f.m.material.opacity = 0.7 * (1 - f.k);
      }
    },
    start() {
      gates.forEach(g => { g.passed = false; g.missed = false; });
      st.phase = 'countdown'; st.countdown = 3; st.idx = 0; st.t = 0;
      speedTracker.reset();
      st.time = null; st.topSpeed = 0; st.avgSpeed = 0; st.rec = []; st.splits = []; st.lastSplit = null;
      havePrev = false;
      st.misses = 0; st.medal = null; st.score = 0;
      if (v2) {
        const a = this.approach();
        const len = courseLength(centers) + a.distanceTo(centers[0]);
        st.par = parTime({ pathLength: len, gates: centers.length, difficulty, worldPar });
      }
      paint();
    },
    update(dt, dronePos, droneVel, droneYaw) {
      if (st.phase === 'countdown') {
        st.countdown -= dt;
        if (st.countdown <= 0) { st.phase = 'running'; st.t = 0; }
        return;
      }
      if (st.phase !== 'running') return;
      st.t += dt;
      if (ghostMesh) {
        const pose = ghostState.enabled && ghostState.data ? ghostPoseAt(ghostState.data, st.t) : null;
        ghostMesh.visible = !!pose && !pose.done;
        if (pose) { ghostMesh.position.set(pose.x, pose.y, pose.z); ghostMesh.rotation.y = pose.yaw; }
      }
      if (v2) {
        // v2: velocidad REAL por posición/tiempo (ventana 250 ms), ignorando teletransportes (gate-stats.js)
        speedTracker.add(dt, dronePos);
        st.avgSpeed = speedTracker.avg;
        st.topSpeed = topSpeedFor({ tracked: speedTracker.top, avg: speedTracker.avg, reported: droneVel.length() });
      } else st.topSpeed = Math.max(st.topSpeed, droneVel.length());
      if ((recSkip = (recSkip + 1) % 2) === 0) {
        st.rec.push([dronePos.x, dronePos.y, dronePos.z, droneYaw]);
      }
      const g = gates[st.idx];
      let through = false;
      if (g) {
        // el aro está en el plano local XY (lookAt hacia el siguiente): su eje es +Z local
        gateNormal.set(0, 0, 1).applyQuaternion(g.mesh.quaternion);
        through = havePrev
          ? segmentPassesGate(prevPos, dronePos, g.center, gateNormal, PASS_R)
          : false;
        // primer paso tras arrancar: sin segmento previo, exigir estar prácticamente en el centro
        if (!havePrev) through = dronePos.distanceTo(g.center) < GATE_R * 0.35;
      }
      if (v2 && g && !through && havePrev && !g.missed) {
        // cruzó el plano del aro pero por fuera del radio de paso → fallo (una vez por gate)
        const s0 = _d.copy(prevPos).sub(g.center).dot(gateNormal);
        const s1 = _d2.copy(dronePos).sub(g.center).dot(gateNormal);
        if (s0 * s1 < 0) {
          const k = s0 / (s0 - s1);
          _d.copy(prevPos).lerp(dronePos, k).sub(g.center);
          if (_d.length() > PASS_R && _d.length() < GATE_R * 4) { g.missed = true; st.misses++; }
        }
      }
      prevPos.copy(dronePos); havePrev = true;
      if (g && through) {
        g.passed = true;
        st.splits.push(st.t);
        st.lastSplit = { t: st.t, at: st.t,
          delta: st.splits.length > 1 ? st.t - st.splits[st.splits.length - 2] : st.t };
        const fm = new THREE.Mesh(
          new THREE.TorusGeometry(GATE_R * 1.05, GATE_R * 0.05, 10, 60),
          new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.7,
            blending: THREE.AdditiveBlending, depthWrite: false }));
        fm.position.copy(g.center); fm.quaternion.copy(g.mesh.quaternion);
        grp.add(fm);
        flashes.push({ m: fm, k: 0 });
        st.idx++;
        paint();
        if (st.idx >= gates.length) {
          st.phase = 'finished'; st.time = st.t;
          if (v2 && st.par) {
            st.medal = gateRushMedal({ time: st.time, par: st.par, misses: st.misses });
            st.score = gateRushScore({ time: st.time, par: st.par, misses: st.misses });
          }
        }
      }
    },
    dispose() {
      scene.remove(grp);
      // glow/beam/trim/migas/flashes: geometrías, materiales y texturas propios del grupo
      grp.traverse(disposeObject);
      flashes.length = 0;
      ringGeo.dispose(); trimGeo.dispose(); matNext.dispose(); matIdle.dispose(); matDone.dispose();
      pathGeo.dispose(); pathMat.dispose();
    },
  };
}

// Mejores tiempos por escena+dificultad — localStorage hasta store server-side (P9).
export function bestTime(cid, t, difficulty = 'media') {
  const k = `ab.fv.best.${cid}.gaterush.${difficulty}`;
  let prevRaw = NaN;
  try { prevRaw = parseFloat(localStorage.getItem(k)); } catch { /* almacenamiento bloqueado */ }
  const prev = Number.isFinite(prevRaw) ? prevRaw : null;   // récord anterior (null = primera marca)
  if (t != null && (prev == null || t < prev)) {
    // Safari privado / cuota llena lanzaba aquí y la tarjeta de resultado nunca aparecía
    try { localStorage.setItem(k, String(t)); } catch { /* el récord no persiste, el resultado sí se muestra */ }
    return { best: t, isNew: true, prev };
  }
  return { best: prev, isNew: false, prev };
}
