// volar.js — FLIGHTVERSE /volar: vuelo jugable sobre la escena real (P3).
// Escena unificada (terreno DSM+orto vía flightverse/scene.js) + dron con
// física de timestep fijo (flightverse/runtime.js) + ghost del vuelo REAL
// (track GPS 1Hz interpolado — el dato más honesto del juego: eso voló ahí).
// HUD: arquitectura de 4 esquinas + barra inferior, cero solapamientos.
// ?autotest=1 → 5s de vuelo sintético y reporte en window.__volar (gate CDP).
import * as THREE from '/vendor/three.module.js';
import { loadManifest, loadTerrain, loadTrack, attachSplat } from '/flightverse/scene.js';
import { createLoop, createInput, createDrone, MODES, RIGS, STEP } from '/flightverse/runtime.js';
import { createGateRush, bestTime } from '/flightverse/gaterush.js';
import { createRecorder } from '/flightverse/recorder.js';
import {
  EffectComposer, RenderPass, EffectPass,
  SMAAEffect, SMAAPreset, BloomEffect,
  ToneMappingEffect, ToneMappingMode, VignetteEffect,
} from '/vendor/postprocessing.module.js';

const Q = new URLSearchParams(location.search);
const CID = (Q.get('m') || '').replace(/[^\w-]/g, '');
const AT = Q.get('autotest');
const AUTOTEST = AT === '1' || AT === 'record';   // ambos vuelan input sintético
const report = { ready: false, done: false, errors: [], cid: CID };
window.__volar = report;

const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const M_LAT = 111320;

function hud() {
  document.body.insertAdjacentHTML('beforeend', `
  <div class="vl-hud" id="vl-hud">
    <div class="vl-corner tl">
      <a class="vl-back" href="mundo.html">← Mundo</a>
      <div class="vl-scene" id="vl-scene"></div>
    </div>
    <div class="vl-corner tr">
      <div class="vl-metric"><span id="vl-agl">—</span><label>ALT AGL</label></div>
      <div class="vl-metric"><span id="vl-spd">—</span><label>VEL m/s</label></div>
    </div>
    <div class="vl-corner bl">
      <div class="vl-mode" id="vl-mode"></div>
      <div class="vl-rig" id="vl-rig"></div>
      <button class="vl-rec" id="vl-rec">● Grabar</button>
    </div>
    <div class="vl-corner br">
      <div class="vl-ghost" id="vl-ghost"></div>
      <div class="vl-fps" id="vl-fps"></div>
    </div>
    <div class="vl-center-top" id="vl-challenge"></div>
    <canvas class="vl-minimap" id="vl-minimap" width="180" height="180"></canvas>
    <div class="vl-count" id="vl-count"></div>
    <div class="vl-result" id="vl-result"></div>
    <div class="vl-help" id="vl-help">
      <b>Controles</b><br>
      WASD mover · R/F subir/bajar · Q/E girar · mouse mirar (click captura)<br>
      Shift turbo · Space freno · 1-5 modo · C cámara · G ghost · P foto-real · V grabar · H ayuda
    </div>
  </div>`);
}

async function main() {
  if (!CID) { location.replace('mundo.html'); return; }
  document.title = 'AeroBrain — Volar';
  hud();
  const say = m => { $('#vl-scene').textContent = m; };
  say('Cargando escena…');

  const man = await loadManifest(CID);
  if (!man.capabilities?.terrain) throw new Error('escena sin terreno volable');
  $('#vl-scene').textContent = man.name;
  // primera impresión: controles visibles 6s (H los trae de vuelta)
  $('#vl-help').classList.add('show');
  setTimeout(() => $('#vl-help').classList.remove('show'), 6000);

  // ── escena three (flags según README de postprocessing: AA lo hace SMAA,
  // depth/stencil viven en los buffers del composer) ──
  const renderer = new THREE.WebGLRenderer({
    powerPreference: 'high-performance', antialias: false, stencil: false, depth: false,
  });
  renderer.toneMapping = THREE.NoToneMapping;   // el tone mapping va al FINAL del pipeline
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.setSize(innerWidth, innerHeight);
  document.body.prepend(renderer.domElement);
  renderer.domElement.className = 'vl-canvas';
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x0A0C10);
  scene.fog = new THREE.Fog(0x0A0C10, 500, 1600);
  const camera = new THREE.PerspectiveCamera(60, innerWidth / innerHeight, 0.3, 4000);
  scene.add(new THREE.AmbientLight(0xffffff, 0.85));
  const sun = new THREE.DirectionalLight(0xffffff, 1.25);
  sun.position.set(250, 420, 120);
  scene.add(sun);

  // look premium: un solo EffectPass fusiona SMAA+Bloom+ACES+Vignette en un shader
  const composer = new EffectComposer(renderer, { frameBufferType: THREE.HalfFloatType });
  composer.addPass(new RenderPass(scene, camera));
  composer.addPass(new EffectPass(camera,
    new SMAAEffect({ preset: SMAAPreset.HIGH }),
    new BloomEffect({ mipmapBlur: true, luminanceThreshold: 0.9, intensity: 0.55, radius: 0.7 }),
    new ToneMappingEffect({ mode: ToneMappingMode.ACES_FILMIC }),
    new VignetteEffect({ offset: 0.32, darkness: 0.48 }),
  ));

  const terrain = await loadTerrain(man, { anisotropy: 8 });
  scene.add(terrain.mesh);
  const W = terrain.world;

  // splat héroe: solo si splat_align.py lo dejó 'aligned' (RMSE sub-métrico).
  // Carga DESPUÉS del terreno (el juego ya es volable mientras llega el ksplat).
  let splat = null;
  if (man.capabilities?.splat && man.transforms?.splat?.status === 'aligned') {
    attachSplat(man, scene, {
      onProgress: p => { if (p < 100) $('#vl-scene').textContent = `${man.name} · splat ${Math.round(p)}%`; },
    }).then(s => {
      splat = s;
      $('#vl-scene').textContent = `${man.name} · foto-real ±${(s.rmse * 100).toFixed(0)}cm`;
      report.splat = { aligned: s.aligned, rmse_m: s.rmse };
    }).catch(e => {
      report.errors.push('splat: ' + e.message);
      $('#vl-scene').textContent = man.name;
    });
  }

  // dron visible (proxy honesto: cuerpo + 4 rotores, sin assets externos)
  const drone = createDrone({ heightAt: terrain.heightAt, spawn: man.spawn });
  const dmesh = new THREE.Group();
  const body = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.4, 1.6),
    new THREE.MeshLambertMaterial({ color: 0xE6EBF2 }));
  dmesh.add(body);
  const rotG = new THREE.MeshLambertMaterial({ color: 0x45A0E6 });
  for (const [x, z] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) {
    const r = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.55, 0.08, 12), rotG);
    r.position.set(x * 1.05, 0.25, z * 1.05);
    dmesh.add(r);
  }
  scene.add(dmesh);

  // ── ghost del vuelo real ──
  let ghost = null;
  const track = await loadTrack(man);
  if (track?.points?.length > 3 && W.center_wgs84) {
    const [clon, clat] = W.center_wgs84;
    const mlon = M_LAT * Math.cos(clat * Math.PI / 180);
    const p0 = track.points[0];
    // frame local: +x=este, +z=sur (lat baja) — misma convención que el terreno
    const g0 = terrain.heightAt((p0.lon - clon) * mlon, (clat - p0.lat) * M_LAT);
    const pts = track.points.map(p => new THREE.Vector3(
      (p.lon - clon) * mlon,
      (g0 ?? 0) + (p.rel_alt || 0),
      (clat - p.lat) * M_LAT,
    ));
    const line = new THREE.Line(
      new THREE.BufferGeometry().setFromPoints(pts),
      new THREE.LineBasicMaterial({ color: 0x52C79A, transparent: true, opacity: 0.55 }));
    const marker = new THREE.Mesh(new THREE.SphereGeometry(0.9, 12, 10),
      new THREE.MeshLambertMaterial({ color: 0x52C79A }));
    const grp = new THREE.Group();
    grp.add(line); grp.add(marker); grp.visible = true;
    scene.add(grp);
    // t viene como datetime string ("2026-07-04 16:03:58") en los SRT reales;
    // normalizar a segundos desde el inicio, fallback = índice (muestreo 1Hz)
    const T = track.points.map((p, i) => {
      if (typeof p.t === 'number') return p.t;
      const ms = Date.parse(String(p.t || '').replace(' ', 'T'));
      return Number.isFinite(ms) ? ms / 1000 : i;
    });
    const tBase = T[0] || 0;
    for (let i = 0; i < T.length; i++) T[i] -= tBase;
    const dur = T[T.length - 1] || 1;
    ghost = { grp, marker, pts, T, dur, t: 0, on: true };
    $('#vl-ghost').textContent = `ghost · vuelo real ${Math.round(dur)}s`;
  } else {
    $('#vl-ghost').textContent = 'sin track';
  }

  // ── estado de juego ──
  const input = createInput(renderer.domElement);
  let modeKey = 'asistido', rigIx = 0;
  const setMode = k => { modeKey = k; $('#vl-mode').textContent = `modo · ${MODES[k].label}`; };
  const setRig = ix => {
    rigIx = ((ix % RIGS.length) + RIGS.length) % RIGS.length;
    camera.fov = RIGS[rigIx].fov; camera.updateProjectionMatrix();
    $('#vl-rig').textContent = `cámara · ${RIGS[rigIx].label}`;
  };
  setMode('asistido'); setRig(0);
  const modeKeys = { Digit1: 'cinematico', Digit2: 'asistido', Digit3: 'fpv', Digit4: 'arcade', Digit5: 'dios' };
  addEventListener('keydown', e => {
    if (modeKeys[e.code]) setMode(modeKeys[e.code]);
    if (e.code === 'KeyC') setRig(rigIx + 1);
    if (e.code === 'KeyG' && ghost) { ghost.on = !ghost.on; ghost.grp.visible = ghost.on; }
    if (e.code === 'KeyH') $('#vl-help').classList.toggle('show');
    if (e.code === 'KeyT') startReto();
    if (e.code === 'KeyP' && splat) splat.object.visible = !splat.object.visible;
    if (e.code === 'Escape' && replay) { replay = null; if (resultShown) $('#vl-result').classList.add('show'); }
  });
  renderer.domElement.addEventListener('click', () => { if (modeKey === 'fpv') input.requestLock(); });
  addEventListener('resize', () => {
    camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix();
    renderer.setSize(innerWidth, innerHeight);
    composer.setSize(innerWidth, innerHeight);
  });

  // ── Gate Rush (desafío del slice) + replay ──
  let reto = null, replay = null, resultShown = false;
  const startReto = () => {
    $('#vl-result').classList.remove('show'); $('#vl-result').innerHTML = '';
    replay = null; resultShown = false;
    if (reto) reto.dispose();
    reto = createGateRush({ scene, trackPts: ghost?.pts, world: W, heightAt: terrain.heightAt });
    reto.start();
  };
  const startReplay = () => {
    if (!reto?.state.rec.length) return;
    $('#vl-result').classList.remove('show');
    replay = { rec: reto.state.rec, f: 0 };
  };
  const showResult = () => {
    resultShown = true;
    const t = reto.state.time;
    const { best, isNew } = bestTime(CID, t);
    $('#vl-result').innerHTML = `
      <div class="vl-result-card">
        <div class="vl-result-k">GATE RUSH · COMPLETADO</div>
        <div class="vl-result-time">${t.toFixed(2)}<small>s</small></div>
        <div class="vl-result-rows">
          <span>${isNew ? '★ nuevo récord' : `récord ${best?.toFixed(2)}s`}</span>
          <span>vel. máx ${reto.state.topSpeed.toFixed(1)} m/s</span>
          <span>${reto.state.total} gates</span>
        </div>
        <div class="vl-result-btns">
          <button data-act="retry">Reintentar</button>
          <button data-act="replay">Ver replay</button>
          <a href="mundo.html">Mundo</a>
        </div>
      </div>`;
    $('#vl-result').classList.add('show');
  };
  $('#vl-result').addEventListener('click', e => {
    const act = e.target.closest('[data-act]')?.dataset.act;
    if (act === 'retry') startReto();
    if (act === 'replay') startReplay();
  });

  // cinemático: tour orbital sobre el centro de la escena
  let tourT = 0;
  const diag = Math.hypot(...W.size_m);

  // ── minimapa táctico: la ortofoto REAL como radar (dron/ghost/gates) ──
  const mm = { cv: $('#vl-minimap'), img: null, ready: false };
  if (man.assets?.ortho) {
    const im = new Image();
    im.onload = () => { mm.img = im; mm.ready = true; };
    im.src = man.assets.ortho;
  }
  const mmXY = (x, z) => [
    (x / W.size_m[0] + 0.5) * mm.cv.width,
    (z / W.size_m[1] + 0.5) * mm.cv.height,
  ];
  function drawMinimap() {
    if (!mm.ready) return;
    const c = mm.cv.getContext('2d');
    c.clearRect(0, 0, mm.cv.width, mm.cv.height);
    c.globalAlpha = 0.92;
    c.drawImage(mm.img, 0, 0, mm.cv.width, mm.cv.height);
    c.globalAlpha = 1;
    if (reto?.gates) for (let i = 0; i < reto.gates.length; i++) {
      const g = reto.gates[i];
      const [gx, gz] = mmXY(g.center.x, g.center.z);
      c.beginPath(); c.arc(gx, gz, 3, 0, 7);
      c.strokeStyle = g.passed ? '#52C79A' : (i === reto.state.idx ? '#45A0E6' : '#566274');
      c.lineWidth = 1.6; c.stroke();
    }
    if (ghost?.on) {
      const [gx, gz] = mmXY(ghost.marker.position.x, ghost.marker.position.z);
      c.fillStyle = '#52C79A'; c.beginPath(); c.arc(gx, gz, 2.4, 0, 7); c.fill();
    }
    const [dx, dz] = mmXY(drone.pos.x, drone.pos.z);
    c.save(); c.translate(dx, dz); c.rotate(-drone.yaw);
    c.fillStyle = '#fff';
    c.beginPath(); c.moveTo(0, -6); c.lineTo(4, 5); c.lineTo(-4, 5); c.closePath(); c.fill();
    c.restore();
  }

  // llegada cinematográfica: swoop desde vista de mapa hacia el rig (skip en autotest)
  let arrival = AT ? null : { t: 0, dur: 3.4 };

  let simT = 0;
  const auto = AUTOTEST ? { until: 5 } : null;
  const autoReto = AT === 'gaterush' ? { last: 0, replayed: false } : null;

  // ── Quick Record (WebM del canvas — camino instantáneo del Video Studio) ──
  const recorder = createRecorder(renderer.domElement);
  const recBtn = $('#vl-rec');
  const toggleRec = async () => {
    if (!recorder.supported) { recBtn.textContent = 'grabación no soportada'; return; }
    if (recorder.recording) {
      const blob = await recorder.stop();
      recBtn.classList.remove('on'); recBtn.textContent = '● Grabar';
      if (blob) recorder.download(blob, `volar_${CID}_${new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-')}.webm`);
    } else if (recorder.start()) recBtn.classList.add('on');
  };
  recBtn.addEventListener('click', toggleRec);
  addEventListener('keydown', e => { if (e.code === 'KeyV') toggleRec(); });
  if (AT === 'record') {
    setTimeout(() => {
      const started = recorder.start();
      setTimeout(async () => {
        const blob = started ? await recorder.stop() : null;
        report.recordBytes = blob?.size || 0;
        report.recordMime = blob?.type || null;
        report.ok = (blob?.size || 0) > 50000;
        report.done = true;
      }, 2500);
    }, 1000);
  }
  const P = new THREE.Vector3();
  const loop = createLoop({
    update(dt) {
      simT += dt;
      if (replay) {
        // replay: la grabación (60Hz) manda; física apagada, interpolación intacta
        replay.f += dt * 60;
        const n = replay.rec.length;
        if (replay.f >= n - 1) replay.f = 0;
        const i = Math.floor(replay.f), f = replay.f - i;
        const a = replay.rec[i], b = replay.rec[Math.min(i + 1, n - 1)];
        drone.prev.pos.copy(drone.pos); drone.prev.yaw = drone.yaw;
        drone.pos.set(a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, a[2] + (b[2] - a[2]) * f);
        drone.yaw = a[3] + (b[3] - a[3]) * f;
      } else {
        let inp = input.sample();
        if (auto && simT < auto.until) inp = { fwd: 1, strafe: 0, yaw: 0.15, lift: 0.1, boost: simT > 2, brake: false, mouseDX: 0, mouseDY: 0 };
        drone.step(dt, inp, modeKey);
        if (autoReto) {
          // autotest del slice: teleporta por los gates — prueba detección,
          // resultado y replay reales sin fingir sus verificaciones
          if (!reto && simT > 0.5) startReto();
          else if (reto?.state.phase === 'running' && simT - autoReto.last > 0.4) {
            autoReto.last = simT;
            const g = reto.gates[reto.state.idx];
            if (g) { drone.pos.copy(g.center); drone.prev.pos.copy(g.center); }
          } else if (reto?.state.phase === 'finished' && !autoReto.replayed) {
            autoReto.replayed = true;
            startReplay();
            setTimeout(() => {
              report.reto = { time: reto.state.time, gates: reto.state.total, recFrames: reto.state.rec.length };
              report.replayActive = !!replay;
              report.ok = reto.state.total >= 4 && reto.state.time != null
                && reto.state.rec.length > 30 && !!replay;
              report.done = true;
            }, 1200);
          }
        }
        if (reto) {
          reto.update(dt, drone.pos, drone.vel, drone.yaw);
          if (reto.state.phase === 'finished' && !resultShown) showResult();
        }
      }
      if (ghost?.on) {
        ghost.t = (ghost.t + dt) % ghost.dur;
        const i = ghost.T.findIndex(t => t > ghost.t);
        const a = Math.max(0, i - 1), b = Math.max(0, i);
        const ta = ghost.T[a], tb = ghost.T[b] || ta + 1;
        const f = tb > ta ? (ghost.t - ta) / (tb - ta) : 0;
        ghost.marker.position.lerpVectors(ghost.pts[a], ghost.pts[b] || ghost.pts[a], f);
      }
    },
    render(alpha) {
      const o = drone.lerpPose(alpha, P);
      dmesh.position.copy(P);
      dmesh.rotation.set(0, o.yaw, 0, 'YXZ');
      dmesh.rotation.x = THREE.MathUtils.clamp(-drone.vel.dot(new THREE.Vector3(-Math.sin(o.yaw), 0, -Math.cos(o.yaw))) * 0.012, -0.35, 0.35);
      if (arrival) {
        // swoop de entrada: de vista-mapa al rig chase, easeOutCubic
        arrival.t += STEP;
        const k = Math.min(1, arrival.t / arrival.dur);
        const e = 1 - Math.pow(1 - k, 3);
        const back = new THREE.Vector3(Math.sin(o.yaw), 0, Math.cos(o.yaw)).multiplyScalar(14);
        const want = P.clone().add(back).add(new THREE.Vector3(0, 6, 0));
        const hi = P.clone().add(new THREE.Vector3(diag * 0.25, diag * 0.55, diag * 0.35));
        camera.position.lerpVectors(hi, want, e);
        camera.lookAt(P);
        if (k >= 1) arrival = null;
      } else if (modeKey === 'cinematico') {
        tourT += STEP * 0.14;
        camera.position.set(Math.cos(tourT) * diag * 0.42, diag * 0.3, Math.sin(tourT) * diag * 0.42);
        camera.lookAt(0, (W.elev_max - W.elev_min) * 0.4, 0);
      } else {
        const rig = RIGS[rigIx];
        rig.fn(P, o, camera, STEP, rig);
      }
      composer.render();
      drawMinimap();
      // HUD (barato: texto directo, sin re-layout)
      $('#vl-agl').textContent = drone.agl == null ? 'fuera' : `${drone.agl.toFixed(1)} m`;
      $('#vl-spd').textContent = drone.vel.length().toFixed(1);
      $('#vl-fps').textContent = `${Math.round(loop.fps() || 0)} fps`;
      if (recorder.recording) recBtn.textContent = `■ REC ${recorder.seconds.toFixed(0)}s`;
      const ch = $('#vl-challenge'), cnt = $('#vl-count');
      if (replay) {
        ch.textContent = 'REPLAY · ESC para salir'; cnt.classList.remove('show');
      } else if (reto) {
        const st = reto.state;
        if (st.phase === 'countdown') {
          cnt.textContent = String(Math.ceil(st.countdown)); cnt.classList.add('show');
          ch.textContent = 'GATE RUSH';
        } else cnt.classList.remove('show');
        if (st.phase === 'running') ch.textContent = `⏱ ${st.t.toFixed(1)}s · gate ${Math.min(st.idx + 1, st.total)}/${st.total}`;
        if (st.phase === 'finished') ch.textContent = `✔ GATE RUSH · ${st.time.toFixed(2)}s`;
      } else {
        ch.textContent = 'T · iniciar Gate Rush'; cnt.classList.remove('show');
      }
    },
  });
  loop.start();
  report.ready = true;

  if (auto && AT === '1') {
    setTimeout(() => {
      report.fps = Math.round(loop.fps() || 0);
      report.pos = { x: +drone.pos.x.toFixed(1), y: +drone.pos.y.toFixed(1), z: +drone.pos.z.toFixed(1) };
      report.agl = drone.agl == null ? null : +drone.agl.toFixed(1);
      report.distance = Math.round(drone.distance);
      report.ghost = !!ghost;
      report.moved = drone.distance > 20;
      report.ok = report.moved && report.fps >= 20 && Number.isFinite(drone.pos.y);
      report.done = true;
    }, (auto.until + 1.5) * 1000);
  }
}

main().catch(e => {
  report.errors.push(String(e?.message || e));
  report.done = true;
  document.body.insertAdjacentHTML('beforeend',
    `<div class="vl-err">No se pudo iniciar el vuelo: ${esc(e.message)} · <a href="mundo.html">volver al Mundo</a></div>`);
});
