// mundo.js — FLIGHTVERSE /mundo: WORLD SELECT estilo videojuego (Mario Kart
// world map). Islas dinámicas en carrusel snap, selección → panel de misión
// (Libre/Gate Rush/Cinemático = deep-links reales a /volar), récords locales,
// transición de carga de consola. 60fps: solo transform/opacity.
const MESES = ['ene','feb','mar','abr','may','jun','jul','ago','sep','oct','nov','dic'];
const fechaDe = cid => { const m = /(\d{4})(\d{2})(\d{2})/.exec(cid||''); return m ? `${+m[3]} ${MESES[+m[2]-1]} ${m[1]}` : ''; };
const dur = s => { s = Math.round(s||0); return `${Math.floor(s/60)}:${String(s%60).padStart(2,'0')}`; };
// guion no separable en rangos ("18-65m" nunca parte en el guion)
const nbh = t => String(t).replace(/(\d)-(?=\d)/g, '$1\u2011');
const MISSIONS = {
  libre: { label: 'Vuelo libre', sub: 'Explora sin límites', extra: '' },
  gaterush: { label: 'Gate Rush', sub: 'Aros sobre tu ruta real', extra: '&reto=1' },
  cine: { label: 'Cinemático', sub: 'Tour orbital automático', extra: '&modo=cinematico' },
};
const best = cid => { const t = parseFloat(localStorage.getItem(`ab.fv.best.${cid}.gaterush`)); return Number.isFinite(t) ? t : null; };
// poster ligero (ortho_thumb.webp) con capa de respaldo al ortho.webp: si la miniatura da 404
// la capa falla en silencio y se ve la siguiente
// una sola capa: con dos (thumb + ortho de respaldo) el navegador descarga AMBAS
// imágenes siempre. tresd_publish genera ortho_thumb.webp en cada publicación.
const bgLayers = (p, q) => (p ? `url(${q}${p}${q})` : 'none');
const hydratePreview = card => {
  const poster = card?.querySelector('.wi-poster');
  if (!poster || poster.dataset.previewLoaded === 'true') return false;
  const url = poster.dataset.preview || '';
  poster.dataset.previewLoaded = 'true';
  if (url) poster.style.backgroundImage = bgLayers(url, '"');
  return true;
};

const SV = (d, s=13) => `<svg width="${s}" height="${s}" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
const I = {
  plane: SV('<path d="M2.5 10.5L17 3l-4.5 14-3-6z"/>', 16),
  flag: SV('<path d="M5 17V4c3-1.8 6 1.8 9 0v8c-3 1.8-6-1.8-9 0"/>'),
  cam: SV('<rect x="2.5" y="5.5" width="11" height="9" rx="2"/><path d="M13.5 9l4-2.5v7l-4-2.5z"/>'),
  libre: SV('<path d="M2.5 10.5L17 3l-4.5 14-3-6z"/>', 16),
  gaterush: SV('<path d="M5 17V4c3-1.8 6 1.8 9 0v8c-3 1.8-6-1.8-9 0"/>', 16),
  cine: SV('<rect x="2.5" y="5.5" width="11" height="9" rx="2"/><path d="M13.5 9l4-2.5v7l-4-2.5z"/>', 16),
  trophy: SV('<path d="M6 3.5h8v4a4 4 0 01-8 0zM6 5H3.5a2.5 2.5 0 002.5 3M14 5h2.5A2.5 2.5 0 0114 8M10 11.5V15M7 16.5h6"/>', 11),
};
const main = renderShell('mundo.html');
let cfg = { cielo: 'dia', calidad: 'auto', modo: 'asistido', cobertura: 'auto', forma: 'circle', mision: 'libre' };
try { cfg = { ...cfg, ...JSON.parse(localStorage.getItem('ab.fv.launchcfg') || '{}') } } catch {}
cfg.cobertura = ['auto','100','200','400','600','1000'].includes(String(cfg.cobertura)) ? String(cfg.cobertura) : 'auto';
cfg.forma = cfg.forma === 'square' ? 'square' : 'circle';
if (!MISSIONS[cfg.mision]) cfg.mision = 'libre';
const effectiveCoverageChoice = scene => {
  if (cfg.cobertura === 'auto') return 'auto';
  const rows = scene?.coverage?.shapes?.[cfg.forma] || [];
  return rows.some(row => row.ready && String(row.diameter_m) === cfg.cobertura)
    ? cfg.cobertura
    : 'auto';
};
const cfgExtra = (scene=sel) =>
  (cfg.cielo !== 'dia' ? `&cielo=${cfg.cielo}` : '')
  + (cfg.calidad !== 'auto' ? `&calidad=${cfg.calidad}` : '')
  + (cfg.modo !== 'asistido' ? `&modo=${cfg.modo}` : '')
  + (effectiveCoverageChoice(scene) !== 'auto'
    ? `&diametro=${effectiveCoverageChoice(scene)}`
    : '')
  + (cfg.forma !== 'circle' ? `&forma=${cfg.forma}` : '');
let filtro = 'todas';
let scenes = [], sel = null;
let mapLibrePromise = null;

function loadMapLibre() {
  if (window.maplibregl) return Promise.resolve(window.maplibregl);
  if (mapLibrePromise) return mapLibrePromise;
  mapLibrePromise = Promise.all([
    new Promise((resolve, reject) => {
      const existing = document.getElementById('fv-maplibre-css');
      if (existing) { resolve(); return; }
      const link = document.createElement('link');
      link.id = 'fv-maplibre-css';
      link.rel = 'stylesheet';
      link.href = 'vendor/maplibre-gl.css';
      link.addEventListener('load', resolve, { once: true });
      link.addEventListener('error', () => reject(new Error('MapLibre CSS no cargó')), { once: true });
      document.head.append(link);
    }),
    new Promise((resolve, reject) => {
      const existing = document.getElementById('fv-maplibre-js');
      if (existing) { existing.addEventListener('load', resolve, { once: true }); return; }
      const script = document.createElement('script');
      script.id = 'fv-maplibre-js';
      script.src = 'vendor/maplibre-gl.js';
      script.addEventListener('load', resolve, { once: true });
      script.addEventListener('error', () => reject(new Error('MapLibre JS no cargó')), { once: true });
      document.head.append(script);
    }),
  ]).then(() => {
    if (!window.maplibregl) throw new Error('MapLibre no quedó disponible');
    return window.maplibregl;
  }).catch(error => {
    mapLibrePromise = null;
    throw error;
  });
  return mapLibrePromise;
}

function isla(sc, i) {
  const c = sc.capabilities||{}, st = sc.stats||{};
  const site = sc.site || {};
  const rec = best(sc.clip_id);
  return `
  <article class="wi ${c.terrain?'':'off'}" data-i="${i}" style="--d:${i*70}ms"
    role="button" tabindex="0" aria-selected="false"
    aria-label="Seleccionar ${esc(sc.name)}">
    <div class="wi-poster" data-preview="${esc(sc.assets?.poster||'')}"></div>
    <div class="wi-shine"></div>
    <div class="scrim"></div>
    ${c.splat?'<span class="wi-badge">FOTO-REAL</span>':c.mesh?'<span class="wi-badge mesh">MALLA 3D</span>':''}
    ${rec!=null?`<span class="wi-rec">${I.trophy} ${rec.toFixed(1)}s</span>`:''}
    <div class="wi-body">
      <div class="wi-name">${nbh(esc(sc.name))}</div>
      <div class="wi-meta"><span>${fechaDe(sc.clip_id) || (site.scene_id ? 'Sitio estable' : 'Sin fecha')}</span>${st.track_duration_s?`<span>vuelo ${dur(st.track_duration_s)}</span>`:''}</div>
      <div class="wi-stats">
        ${sc.world?.size_m?`<i>${(sc.world.size_m[0]*sc.world.size_m[1]/10000).toFixed(1)}&nbsp;ha</i>`:''}
        ${st.gsd_cm_px?`<i>${st.gsd_cm_px}&nbsp;cm/px</i>`:''}
        ${site.source_count?`<i>${site.source_count}&nbsp;${site.source_count===1?'video':'videos'}</i>`:''}
        ${c.track?'<i>ruta&nbsp;GPS</i>':''}
        ${site.scene_id?`<i>sitio&nbsp;·&nbsp;v${site.version_count||1}</i>`:''}
      </div>
    </div>
  </article>`;
}

function pick(i) {
  sel = scenes[i];
  document.querySelectorAll('.wi').forEach(el => {
    const selected = +el.dataset.i === i;
    el.classList.toggle('sel', selected);
    el.setAttribute('aria-selected', String(selected));
    if (selected) hydratePreview(el);
  });
  const c = sel.capabilities||{}, st = sel.stats||{}, w = sel.world||{};
  const site = sel.site || {}, coverage = sel.coverage?.shapes?.circle || [];
  const integrated = site.source_status?.integrated || site.effective_sources?.length || 0;
  const readyCoverage = coverage.filter(row => row.ready).map(row => row.diameter_m);
  const rec = best(sel.clip_id);
  const mis = MISSIONS[cfg.mision] || MISSIONS.libre;
  const goUrl = `volar.html?m=${encodeURIComponent(sel.clip_id)}${mis.extra}${cfgExtra()}`;
  const p = document.getElementById('w-panel');
  p.innerHTML = c.terrain ? `
    <div class="wp-in">
      <div>
        <div class="wp-name">${nbh(esc(sel.name))}</div>
        <div class="wp-chips">
          ${site.scene_id?`<span class="fv-chip on">sitio estable · ${site.version_count||1} versiones</span>`:''}
          ${site.source_count?`<span class="fv-chip">${integrated}/${site.source_count} videos integrados</span>`:''}
          ${coverage.length?`<span class="fv-chip">cobertura lista ${readyCoverage.length?readyCoverage.join(' / ')+' m':'pendiente'}</span>`:''}
          ${c.splat?`<span class="fv-chip on">splat ${st.splat_cameras||''} cams</span>`:''}
          ${rec!=null?`<span class="fv-chip on">récord ${rec.toFixed(2)}s</span>`:''}
        </div>
        <div class="wp-data">
          ${w.size_m?`<div><b>${(w.size_m[0]*w.size_m[1]/10000).toFixed(1)}</b><span>hectáreas</span></div>`:''}
          ${w.elev_max?`<div><b>${(w.elev_max-w.elev_min).toFixed(0)} m</b><span>desnivel</span></div>`:''}
          ${st.gsd_cm_px?`<div><b>${st.gsd_cm_px}</b><span>cm/px</span></div>`:''}
          ${st.track_distance_m?`<div><b>${(st.track_distance_m/1000).toFixed(2)} km</b><span>vuelo real</span></div>`:''}
          ${st.cloud_points?`<div><b>${(st.cloud_points/1e6).toFixed(1)}M</b><span>puntos</span></div>`:''}
          ${sel.quality?.splat_bytes?`<div><b>${(sel.quality.splat_bytes/1048576).toFixed(0)} MB</b><span>splat</span></div>`:''}
        </div>
      </div>
      <div class="wp-cfg" id="wp-cfg">
        <div class="wp-cfg-g" data-k="cielo"><span>Cielo</span>
          <button data-v="dia">Día</button><button data-v="atardecer">Atardecer</button><button data-v="noche">Noche</button></div>
        <div class="wp-cfg-g" data-k="calidad"><span>Calidad</span>
          <button data-v="auto">Auto</button><button data-v="hd">HD</button><button data-v="extra">Extra</button></div>
        <div class="wp-cfg-g" data-k="modo"><span>Modo</span>
          <button data-v="asistido">Normal</button><button data-v="arcade">Arcade</button><button data-v="dios">Dios</button></div>
        ${coverage.length?`<div class="wp-cfg-g coverage" data-k="cobertura"><span>Cobertura</span>
          <button data-v="auto">Auto</button>${coverage.map(row => `<button data-v="${row.diameter_m}" title="${row.ready?`${Math.round(row.area_m2).toLocaleString('es-CO')} m²`:`Cobertura pendiente: disponible ${row.available_diameter_m||'—'} m`}"${row.ready?'':' disabled'}>${row.diameter_m} m${row.ready?'':' · pendiente'}</button>`).join('')}</div>
        <div class="wp-cfg-g" data-k="forma"><span>Forma</span>
          <button data-v="circle">Círculo</button><button data-v="square">Cuadrado</button></div>`:''}
      </div>
      <div class="wp-go">
        <div class="seg wp-modes" id="wp-modes" role="group" aria-label="Misión">
          ${Object.entries(MISSIONS).map(([k, m]) => `<button type="button" data-mis="${k}" aria-pressed="${k===cfg.mision}" class="${k===cfg.mision?'on':''}">${I[k]} ${m.label}</button>`).join('')}
        </div>
        <p class="wp-mis-sub">${cfg.mision==='gaterush'&&rec!=null?`Bate tu ${rec.toFixed(1)}s`:mis.sub}</p>
        <button class="btn primary lg wp-fly" data-go="${goUrl}">${I.plane} Volar</button>
      </div>
    </div>` : `<div class="wp-in"><div class="wp-name">${nbh(esc(sel.name))}</div>
      <a class="btn" href="tresd.html">Procesar en Estudio 3D</a></div>`;
  p.classList.add('show');
  p.querySelectorAll('.wp-cfg-g').forEach(g => {
    const k = g.dataset.k;
    const selected = k === 'cobertura' ? effectiveCoverageChoice(sel) : cfg[k];
    g.querySelectorAll('button').forEach(b => b.classList.toggle('on', b.dataset.v === selected));
  });
}

function launch(url, poster) {
  const ov = document.getElementById('w-launch');
  ov.querySelector('.wl-bg').style.backgroundImage = bgLayers(poster, "'");
  ov.classList.add('go');
  window.__abReloadOnRestore = true;  // shell.js recarga al volver por bfcache (el overlay .go taparía la página)
  setTimeout(() => { location.href = url; }, 520);
}

async function boot() {
  main.innerHTML = `<div class="page fv-page">
    <header class="fv-hero">
      <div class="fv-kicker">FLIGHTVERSE</div>
      <h1>Mundo</h1>
      <p class="fv-sub">Elige tu isla — lugares reales reconstruidos desde tus vuelos.</p>
      <div class="fv-statbar" id="fv-stats"></div>
      <div class="seg fv-viewseg" role="group" aria-label="Vista">
        <button class="on" data-fvv="cards" aria-pressed="true">Islas</button>
        <button data-fvv="map" aria-pressed="false">Mapa</button>
      </div>
    </header>
    <div id="w-cards">
      <div class="w-bar">
        <div class="w-filters" id="w-filters" role="group" aria-label="Filtrar islas">
          <button class="on" data-f="todas">Todas</button>
          <button data-f="fotoreal">Foto-real</button>
          <button data-f="record">Con récord</button>
          <button data-f="volables">Volables</button>
        </div>
        <div class="w-nav">
          <button class="btn icon" id="w-prev" aria-label="Islas anteriores">${icon('chevL')}</button>
          <button class="btn icon" id="w-next" aria-label="Islas siguientes">${icon('chevR')}</button>
        </div>
      </div>
      <div class="w-railwrap">
        <div class="w-rail" id="w-rail"><div class="fv-loading">Cargando mundo…</div></div>
      </div>
      <div class="w-panel" id="w-panel"></div>
    </div>
    <div class="fv-mapwrap" id="fv-mapwrap" hidden>
      <div class="fv-mapbar">
        <div class="seg" id="fv-layers" role="group" aria-label="Capa base">
          <button class="on" data-ly="sat" aria-pressed="true">Satélite</button>
          <button data-ly="dark" aria-pressed="false">Oscuro</button>
          <button data-ly="plano" aria-pressed="false">Plano</button>
        </div>
        <span class="spacer"></span>
        <button class="btn sm" id="fv-rutas" aria-pressed="false">Rutas reales</button>
        <button class="btn sm" id="fv-fit">Encuadrar todo</button>
      </div>
      <div class="fv-map" id="fv-map"></div>
    </div>
    <div class="w-launch" id="w-launch"><div class="wl-bg"></div><div class="wl-txt">CARGANDO ESCENA<span class="wl-bar"></span></div></div>
  </div>`;
  let sys;
  try { sys = await (await fetch('data/manifest/system.json')).json(); }
  catch { document.getElementById('w-rail').innerHTML = '<div class="fv-loading">Sin manifiesto.</div>'; return; }
  // Una isla por sitio estable: solo la versión activa entra al Mundo. Los modelos
  // todavía no asociados a un sitio permanecen visibles como escenas independientes.
  const stableSites = (sys.scenes || []).filter(site => site.active_version);
  const versioned = new Set((sys.scenes || []).flatMap(site => (site.versions || []).map(v => v.id)));
  const targets = stableSites.map(site => ({ clip_id: site.active_version, site }));
  const seen = new Set(targets.map(row => row.clip_id));
  for (const model of sys.models || []) {
    if (!model.clip_id || versioned.has(model.clip_id) || seen.has(model.clip_id)) continue;
    targets.push({ clip_id: model.clip_id, site: null }); seen.add(model.clip_id);
  }
  const settled = await Promise.allSettled(targets.map(target =>
    fetch(`data/models/${target.clip_id}/scene.v2.json`, { cache: 'no-store' })
      .then(r => r.ok ? r.json() : null).then(man => ({ man, target }))));
  scenes = settled.map(s => {
    if (s.status !== 'fulfilled' || !s.value.man) return null;
    const { man, target } = s.value;
    if (target.site) {
      const active = (target.site.versions || []).find(v => v.id === target.site.active_version) || {};
      const evidence = target.site.source_evidence || [];
      const status = Object.fromEntries(['integrated','eligible','duplicate','insufficient_overlap','registration_failed']
        .map(key => [key, evidence.filter(row => row.status === key).length]));
      man.site = { ...(man.site || {}), scene_id: target.site.id, title: target.site.title,
        active_version: target.site.active_version, is_active_version: true,
        version_count: (target.site.versions || []).length,
        source_count: target.site.source_inventory?.videos?.length || 0,
        source_status: status, effective_sources: active.effective_sources || [],
        dropped_sources: active.dropped_sources || [] };
      man.name = target.site.title || man.name;
    }
    return man;
  }).filter(Boolean);
  scenes.sort((a,b) => ((b.capabilities?.terrain|0)-(a.capabilities?.terrain|0))
    || ((b.capabilities?.splat|0)-(a.capabilities?.splat|0))
    || String(b.clip_id).localeCompare(String(a.clip_id)));

  const nFly = scenes.filter(s=>s.capabilities?.terrain).length;
  const nSp = scenes.filter(s=>s.capabilities?.splat).length;
  const secs = scenes.reduce((t,s)=>t+(s.stats?.track_duration_s||0),0);
  document.getElementById('fv-stats').innerHTML =
    `<span><b>${nFly}</b><em>islas volables</em></span><span><b>${nSp}</b><em>foto-realistas</em></span>`+
    (secs?`<span><b>${dur(secs)}</b><em>de vuelo real</em></span>`:'');

  const rail = document.getElementById('w-rail');
  let previewObserver = null;
  const observePreviews = () => {
    previewObserver?.disconnect();
    const cards = [...rail.querySelectorAll('.wi')];
    if (!('IntersectionObserver' in window)) {
      cards.slice(0, 2).forEach(hydratePreview);
      return;
    }
    previewObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        hydratePreview(entry.target);
        previewObserver?.unobserve(entry.target);
      });
    }, { root: rail, rootMargin: '0px 280px', threshold: 0.01 });
    cards.forEach(card => previewObserver.observe(card));
  };
  let railShown = false;
  const applyFiltro = () => {
    const f = filtro;
    const list = scenes.map((sc, i) => ({ sc, i })).filter(({ sc }) =>
      f === 'todas' ? true
      : f === 'fotoreal' ? sc.capabilities?.splat
      : f === 'record' ? best(sc.clip_id) != null
      : sc.capabilities?.terrain);
    rail.classList.toggle('settled', railShown);   // la entrada escalonada solo en el primer montaje
    railShown = true;
    rail.innerHTML = list.length
      ? list.map(({ sc, i }) => isla(sc, i)).join('')
      : '<div class="fv-loading">Nada con ese filtro.</div>';
    observePreviews();
    rail.scrollLeft = 0;
    requestAnimationFrame(() => syncArrows());
    const first = list[0];
    if (first) pick(first.i);
  };
  document.getElementById('w-filters').addEventListener('click', e => {
    const b = e.target.closest('[data-f]'); if (!b) return;
    filtro = b.dataset.f;
    document.querySelectorAll('#w-filters button').forEach(x => x.classList.toggle('on', x === b));
    applyFiltro();
  });
  const step = () => (rail.querySelector('.wi')?.getBoundingClientRect().width || 320) + 16;
  document.getElementById('w-prev').addEventListener('click', () => rail.scrollBy({ left: -step(), behavior: 'smooth' }));
  document.getElementById('w-next').addEventListener('click', () => rail.scrollBy({ left: step(), behavior: 'smooth' }));
  const syncArrows = () => {
    const max = rail.scrollWidth - rail.clientWidth - 2;
    document.getElementById('w-prev').disabled = rail.scrollLeft <= 2;
    document.getElementById('w-next').disabled = rail.scrollLeft >= max;
  };
  rail.addEventListener('scroll', syncArrows, { passive: true });
  addEventListener('resize', syncArrows);
  applyFiltro();
  syncArrows();
  const activateCard = el => {
    pick(+el.dataset.i);
    el.scrollIntoView({ behavior:'smooth', inline:'nearest', block:'nearest' });
  };
  rail.addEventListener('click', e => {
    const el = e.target.closest('.wi'); if (!el) return;
    activateCard(el);
  });
  rail.addEventListener('keydown', e => {
    if (e.key !== 'Enter' && e.key !== ' ') return;
    const el = e.target.closest('.wi'); if (!el) return;
    e.preventDefault();
    activateCard(el);
  });
  document.getElementById('w-panel').addEventListener('click', e => {
    const cb = e.target.closest('.wp-cfg-g button[data-v]');
    if (cb) {
      const g = cb.closest('.wp-cfg-g');
      cfg[g.dataset.k] = cb.dataset.v;
      localStorage.setItem('ab.fv.launchcfg', JSON.stringify(cfg));
      pick(scenes.indexOf(sel));
      return;
    }
    const mb = e.target.closest('[data-mis]');
    if (mb) {
      cfg.mision = mb.dataset.mis;
      localStorage.setItem('ab.fv.launchcfg', JSON.stringify(cfg));
      pick(scenes.indexOf(sel));
      document.querySelector(`#wp-modes [data-mis="${cfg.mision}"]`)?.focus({ preventScroll: true });
      return;
    }
    const b = e.target.closest('[data-go]'); if (!b) return;
    launch(b.dataset.go, sel?.assets?.poster || '');
  });
  // tilt 3D solo con puntero fino
  if (matchMedia('(pointer:fine)').matches) rail.addEventListener('mousemove', e => {
    const el = e.target.closest('.wi'); if (!el) return;
    const r = el.getBoundingClientRect();
    el.style.transform = `perspective(700px) rotateY(${((e.clientX-r.left)/r.width-.5)*7}deg) rotateX(${(.5-(e.clientY-r.top)/r.height)*5}deg)`;
  }), rail.addEventListener('mouseout', e => { const el = e.target.closest('.wi'); if (el) el.style.transform=''; });
  // ── MAPA v2: capas, huellas de cobertura, rutas reales, popup de misión ──
  let map = null, rutasOn = false;
  const RASTER = t => ({ version:8, sources:{ b:{ type:'raster', tiles:[t], tileSize:256 } },
    layers:[{ id:'b', type:'raster', source:'b' }] });
  const LAYERS = {
    sat: RASTER('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}'),
    dark: RASTER('https://basemaps.cartocdn.com/dark_all/{z}/{x}/{y}@2x.png'),
    plano: RASTER('https://basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}@2x.png'),
  };
  let mapBounds = null;
  const MLAT = 111320;
  const footprints = { type:'FeatureCollection', features: scenes.flatMap(sc => {
    const c = sc.world?.center_wgs84, s = sc.world?.size_m; if (!c || !s) return [];
    const rx = (s[0] / 2) / (MLAT * Math.cos(c[1] * Math.PI / 180)), ry = (s[1] / 2) / MLAT;
    const ring = [];
    for (let i = 0; i <= 40; i++) {
      const a = i / 40 * Math.PI * 2;
      ring.push([c[0] + Math.cos(a) * rx, c[1] + Math.sin(a) * ry]);
    }
    return [{ type:'Feature', properties:{ splat: sc.capabilities?.splat ? 1 : 0 },
              geometry:{ type:'Polygon', coordinates:[ring] } }];
  }) };
  const addOverlays = () => {
    if (map.getSource('fp')) return;
    map.addSource('fp', { type:'geojson', data: footprints });
    map.addLayer({ id:'fp-fill', type:'fill', source:'fp',
      paint:{ 'fill-color':['case',['==',['get','splat'],1],'#45A0E6','#8A97A8'], 'fill-opacity':0.14 } });
    map.addLayer({ id:'fp-line', type:'line', source:'fp',
      paint:{ 'line-color':['case',['==',['get','splat'],1],'#45A0E6','#8A97A8'], 'line-width':1.6, 'line-opacity':0.65 } });
    if (rutasOn) drawRutas();
  };
  async function drawRutas() {
    const feats = [];
    for (const sc of scenes) {
      if (!sc.assets?.track) continue;
      try {
        const t = await (await fetch(sc.assets.track)).json();
        feats.push({ type:'Feature', properties:{},
          geometry:{ type:'LineString', coordinates: t.points.map(p => [p.lon, p.lat]) } });
      } catch { /* sin ruta */ }
    }
    if (!map.getSource('rt')) {
      map.addSource('rt', { type:'geojson', data:{ type:'FeatureCollection', features: feats } });
      map.addLayer({ id:'rt-line', type:'line', source:'rt',
        paint:{ 'line-color':'#52C79A', 'line-width':2.2, 'line-opacity':0.85 } });
    }
  }
  const missionPopup = sc => {
    const rec = best(sc.clip_id), st = sc.stats || {};
    const go = e => `volar.html?m=${encodeURIComponent(sc.clip_id)}${e}${cfgExtra(sc)}`;
    return `<div class="fv-pop">
      <div class="fv-pop-poster" style="background-image:${esc(bgLayers(sc.assets?.poster||'', "'"))}"></div>
      <b>${esc(sc.name)}</b>
      <span>${st.gsd_cm_px ? st.gsd_cm_px + ' cm/px · ' : ''}${st.track_duration_s ? dur(st.track_duration_s) + ' vuelo real' : ''}${rec != null ? ' · récord ' + rec.toFixed(1) + 's' : ''}</span>
      ${sc.capabilities?.terrain ? `<div class="fv-pop-btns">
        <a data-golaunch="${go('')}" data-poster="${esc(sc.assets?.poster||'')}">Libre</a>
        <a class="hot" data-golaunch="${go('&reto=1')}" data-poster="${esc(sc.assets?.poster||'')}">Gate Rush</a>
        <a data-golaunch="${go('&modo=cinematico')}" data-poster="${esc(sc.assets?.poster||'')}">Cine</a>
      </div>` : '<em>en preparación</em>'}
    </div>`;
  };
  async function showMap() {
    document.getElementById('fv-mapwrap').hidden = false;
    document.getElementById('w-cards').hidden = true;
    if (map) { map.resize(); return; }
    try {
      await loadMapLibre();
    } catch (error) {
      document.getElementById('fv-mapwrap').hidden = true;
      document.getElementById('w-cards').hidden = false;
      throw error;
    }
    mapBounds = new maplibregl.LngLatBounds();
    map = new maplibregl.Map({ container: document.getElementById('fv-map'), style: LAYERS.sat,
      center: [-74.06, 4.75], zoom: 11, attributionControl: false });
    map.addControl(new maplibregl.NavigationControl({ showCompass: false }), 'top-right');
    map.on('load', addOverlays);
    for (const sc of scenes) {
      const c = sc.world?.center_wgs84; if (!c) continue;
      mapBounds.extend(c);
      const pop = new maplibregl.Popup({ offset: 20, closeButton: false, maxWidth: '260px' })
        .setHTML(missionPopup(sc));
      const dot = document.createElement('div');
      dot.className = 'fv-pin2' + (sc.capabilities?.splat ? ' splat' : '');
      dot.innerHTML = `<span class="fv-pin-img" style="background-image:${esc(bgLayers(sc.assets?.poster||'', "'"))}"></span><span class="fv-pin-lb">${esc(sc.name.split(' · ')[0])}</span>`;
      new maplibregl.Marker({ element: dot }).setLngLat(c).setPopup(pop).addTo(map);
      dot.addEventListener('click', () => map.flyTo({ center: c, zoom: 15.5, speed: 1.35 }));
    }
    if (!mapBounds.isEmpty()) map.fitBounds(mapBounds, { padding: 70, maxZoom: 14 });
    document.getElementById('fv-layers').addEventListener('click', e => {
      const b = e.target.closest('[data-ly]'); if (!b) return;
      document.querySelectorAll('#fv-layers button').forEach(x => { x.classList.toggle('on', x === b); x.setAttribute('aria-pressed', x === b); });
      map.setStyle(LAYERS[b.dataset.ly]);
      map.once('styledata', () => setTimeout(addOverlays, 80));
    });
    document.getElementById('fv-rutas').addEventListener('click', e => {
      rutasOn = !rutasOn;
      e.currentTarget.classList.toggle('on', rutasOn); e.currentTarget.setAttribute('aria-pressed', rutasOn);
      if (rutasOn) drawRutas();
      else if (map.getLayer('rt-line')) { map.removeLayer('rt-line'); map.removeSource('rt'); }
    });
    document.getElementById('fv-fit').addEventListener('click', () =>
      map.fitBounds(mapBounds, { padding: 70, maxZoom: 14, duration: 900 }));
    document.getElementById('fv-map').addEventListener('click', e => {
      const a = e.target.closest('[data-golaunch]'); if (!a) return;
      launch(a.dataset.golaunch, a.dataset.poster);
    });
  }
  document.querySelector('.fv-viewseg').addEventListener('click', e => {
    const b = e.target.closest('[data-fvv]'); if (!b) return;
    document.querySelectorAll('.fv-viewseg button').forEach(x => { x.classList.toggle('on', x === b); x.setAttribute('aria-pressed', x === b); });
    if (b.dataset.fvv === 'map') {
      void showMap().catch(error => {
        main.insertAdjacentHTML('beforeend', `<div class="fv-loading">Mapa: ${esc(error.message)}</div>`);
      });
    } else {
      document.getElementById('fv-mapwrap').hidden = true;
      document.getElementById('w-cards').hidden = false;
    }
  });
}
boot().catch(e => main.insertAdjacentHTML('beforeend', `<div class="fv-loading">Error: ${esc(e.message)}</div>`));
